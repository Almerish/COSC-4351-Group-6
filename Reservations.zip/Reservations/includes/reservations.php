<?php

require "connection.php";

if(isset($_SESSION['id']))      // we have set id and username to Session variable   //isset will check if the variable is not null
{
    echo '<p class="text-white bg-dark text-center">Welcome '. $_SESSION['username'] .', Create your reservation here!</p>';
}

function between($val, $x, $y)      // function to decide the value is correct or not
{
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

$all_error = $name_error = $guests_error = $tele_error = $email_error = ""; 


session_start();

if(isset($_POST['reserv-submit']))  //use button name = reserv-submit in html doc below
{
            // we can add user id = $session['id] but i have to check how it work
    $name = $_POST['name'];
    $date = $_POST['date'];
    $time= $_POST['time'];
    $guests= $_POST['num_guests'];
    $tele = $_POST['tele'];
    $email = $_POST['email'];
    
    if($guests==1 || $guests==2)
    {
        // figure out how to arrange tables and wether we give them post variable or not
    }

    if(empty($name) || empty($date) || empty($time) || empty($guests) || empty($tele) ||empty($email))
    {
        $all_error = "fields cannot be empty";
    }

    elseif(!preg_match("/^[a-zA-Z ]*$/",$name) || !between($name,2,20))          // we can try this or we can do the between function.
    {
        $name_error = "please enter valid name";
    }

    elseif(!preg_match("/^[0-9]*$/", $guests))
    {
        $guests_error = "please enter number of guest";
    }

    elseif(!preg_match("/^[a-zA-Z0-9]*$/", $tele) || !between($tele,6,20))
    {
        $tele_error = "please enter valid number";
    }

    elseif(!preg_match("/^[a-zA-Z0-9@]*$/", $email) || !between($email,6,20))           // i tried this if error comes we can remove it
    {
        $tele_error = "please enter valid email";
    }
    
}
?>
