<?php

emptyInputSignup($name, $email, $mailingaddress, $billingaddress, $pwd, $pwdrepeat){
	$result;
if(empty($name) || empty($email) || empty($mailingaddress) || empty($billingaddress) || empty($pwd) || empty($pwdrepeat)){
	$result = true;	
}
	else{
		$result = false;
	}
	return $result;
}

function invalidEmail($email){
	$result;
if(!filter_var ($email, FILTER_VALIDATE_EMAIL)){
$result = true;	
}
 else{
	 return false;
 }
}

function pwdMatch($pwd, $pwdrepeat){
	$result;
if($pwd !== $pwdrepeat){
	$result = true;
}
	else{
		$result = false;
	}
return $result;
}

function emailExists($conn, $email){
	$sql = "SELECT * FROM users where email = ? ";
	$stmt = mysqli_stmt_init($conn);
	
}
