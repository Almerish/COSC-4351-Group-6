<?php
//include the databse file below
require_once "connection.php";

$username = $password = $confirm_password = $mailing_address = $billing_address = $email =  ""; // we intialize variable
$username_err = $password_err = $confirm_password_err = $mailing_address_err = $billing_address_err = $email_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST")
{

	// this will be for username
	if(empty(trim($_POST["username"])))
	{
        $username_err = "Please enter a username.";
    }

	elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"])))
	{
        $username_err = "Username can only contain letters, numbers, and underscores.";		// restricted username
	}

	else
	{
		if (doesUserExist(trim($_POST["username"]))) {
			$username_err = "This username is already taken.";
		} else {
			$username = trim($_POST["username"]);
		}
		
    }

	// this will be for password
	if(empty(trim($_POST["password"])))
	{
        $password_err = "Please enter a password.";     
    } 
	
	elseif(strlen(trim($_POST["password"])) < 6)
	{
        $password_err = "Password must have atleast 6 characters.";
    } 
	
	else
	{
        $password = trim($_POST["password"]);
    }

	//this will confirm password
	if(empty(trim($_POST["confirm_password"])))
	{
        $confirm_password_err = "Please confirm password.";     
    } 
	
	else
	{
        $confirm_password = trim($_POST["confirm_password"]);
        
		if(empty($password_err) && ($password != $confirm_password))
		{
            $confirm_password_err = "Password did not match.";
        }
    }

	//this will enter the email address
	if(empty(trim($_POST["mailing_address"])))
	{
        $mailing_address_err = "Please enter a valid mailing address.";     
    } 

	else
	{
        $mailing_address = trim($_POST["mailing_address"]);
    }

	// this will enter billing address
	if(empty(trim($_POST["billing_address"])))
	{
        $billing_address_err = "Please enter a valid billing address.";     
    } 

	else
	{
        $billing_address = trim($_POST["billing_address"]);
    }

	// this will take email
	if(empty(trim($_POST["email"])))
	{
        $email_err = "Please enter a valid email.";     
    } 

	else
	{
        $email = trim($_POST["email"]);
    }

	// eneter data in database is remaining
	if (empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($mailing_address_err) && empty($billing_address_err) && empty($email_err)) {
		insertUser($username, $mailing_address, $billing_address, 0, "Credit", $email, $username, $password);
	}
}