<?php

if(isset($_POST["submit"])){
	$name = $_POST["name"];
	$email = $_POST["email"];
	$username = $_POST["uid"];
	$pwd = $_POST["pwd"];
	$pwdrepeat = $_POST["pwdRepeat"];
	
	require_once 'dbh.inc.php';
	require_once 'functions.inc.php';

//This will test to make sure the fields are not empty	
if(emptyInputSignup() !== false){
	header("location: ../signup.php?error=emptyinput");
	exit();
}	

//This is to check to make sure the email is not an invalid entry field
if(invalidEmail($email) !== false){
	header("location: ../signup.php?error=invalidemail");
	exit();
}
//This will check to make sure that the passwords will match
if(pwdMatch($pwd, $pwdRepeat) !== false){
	header("location:../signup.php?error=passworddontmatch");
	exit();
}
	
//This will check to make sure the email isnt already in the database
if(emailExists($conn, $email) !== false){
	header("location:../signup.php?error=emailtaken");
	exit();
}
	createuser($conn,$name,$email,$pwd);
}
else {
	header("location: ../signup.php");
}